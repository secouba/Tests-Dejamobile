package com.DejamobileTest.DejamobileBackendMicroService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DejamobileBackendMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DejamobileBackendMicroServiceApplication.class, args);
	}

}
