package com.DejamobileTest.DejamobileSDKMicroService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DejamobileSdkMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DejamobileSdkMicroServiceApplication.class, args);
	}

}
