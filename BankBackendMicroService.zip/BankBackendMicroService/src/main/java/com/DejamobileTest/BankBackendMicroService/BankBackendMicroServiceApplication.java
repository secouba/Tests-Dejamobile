package com.DejamobileTest.BankBackendMicroService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankBackendMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankBackendMicroServiceApplication.class, args);
	}

}
