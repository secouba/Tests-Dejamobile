package com.DejamobileTest.CardsMicroService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CardsMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CardsMicroServiceApplication.class, args);
	}

}
