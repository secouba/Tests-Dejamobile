package com.DejamobileTest.CardsMicroService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardsMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
